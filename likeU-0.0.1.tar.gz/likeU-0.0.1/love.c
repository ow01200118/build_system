//
#include <stdio.h>
#include <unistd.h>
#include <math.h>

void lovecall()
{
    double love;

    for(love=0; sin(love)+2; love++) {
        printf("I love you. \n");
        sleep(1);
    }
}
